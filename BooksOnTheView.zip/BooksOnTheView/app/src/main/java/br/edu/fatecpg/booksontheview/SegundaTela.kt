package br.edu.fatecpg.booksontheview

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SegundaTela : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_segunda_tela)

        val txtTitulo = findViewById<TextView>(R.id.txtTitulo)
        val txtAutor = findViewById<TextView>(R.id.txtAutor)


        val titulo = intent.getStringExtra("TITULO_LIVRO")
        val autor = intent.getStringExtra("AUTOR_LIVRO")


        txtTitulo.text = "Título: $titulo"
        txtAutor.text = "Autor: $autor"

    }
}