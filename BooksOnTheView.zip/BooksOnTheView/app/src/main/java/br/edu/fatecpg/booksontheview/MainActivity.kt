package br.edu.fatecpg.booksontheview

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        // Referências para os elementos da interface
        val edtTitulo = findViewById<EditText>(R.id.edtTitulo)
        val edtAutor = findViewById<EditText>(R.id.edtAutor)
        val btnCadastrar = findViewById<Button>(R.id.btnCadastrar)

        // Configuração do clique do botão
        btnCadastrar.setOnClickListener {
            // Obtendo os valores inseridos pelo usuário
            val titulo = edtTitulo.text.toString()
            val autor = edtAutor.text.toString()

            // Criando o Intent para iniciar a BookDetailActivity
            val intent = Intent(this, SegundaTela::class.java).apply {
                putExtra("TITULO_LIVRO", titulo)
                putExtra("AUTOR_LIVRO", autor)
            }

            // Iniciando a BookDetailActivity
            startActivity(intent)
    }
    }
}
