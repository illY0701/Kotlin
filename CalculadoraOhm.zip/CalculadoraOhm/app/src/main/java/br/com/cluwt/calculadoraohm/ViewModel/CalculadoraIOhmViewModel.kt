package br.com.cluwt.calculadoraohm.ViewModel

import br.com.cluwt.calculadoraohm.Model.CalculadoraOhm

class CalculadoraIOhmViewModel {

    private val Calculadora = CalculadoraOhm()

    fun CalcularResistencia(Tensao : Double, Corrente : Double) {
        try{
            val Resultado = Calculadora.CalcularResistencia(Tensao,Corrente)
        }
        catch (e: IllegalArgumentException){

        }

    }

}