package br.com.cluwt.calculadoraohm.Model

class CalculadoraOhm {
    fun CalcularResistencia(Tensao : Double, Corrente : Double): Double {
        if(Corrente == 0.0) throw Exception ("Numero não pode ser igual à 0")
        val Resistencia = Tensao/Corrente
        return Resistencia
    }
}