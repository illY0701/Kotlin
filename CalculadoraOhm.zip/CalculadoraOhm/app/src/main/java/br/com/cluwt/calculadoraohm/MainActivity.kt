package br.com.cluwt.calculadoraohm

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.com.cluwt.calculadoraohm.Model.CalculadoraOhm
import br.com.cluwt.calculadoraohm.ViewModel.CalculadoraIOhmViewModel

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Referências de campo de entrada:
        val InputResistencia = findViewById<EditText>(R.id.InputResistencia)
        val InputCorrente = findViewById<EditText>(R.id.InputCorrente)
        val BtnCalcular = findViewById<Button>(R.id.BtnCalcular)

        // Chamada do Objeto:
        val Calculadora = CalculadoraIOhmViewModel()

        // Botão:
        BtnCalcular.setOnClickListener{
            val resistencia = InputResistencia.text.toString().toDouble()
            val corrente = InputCorrente.text.toString().toDouble()


            val ResultadoFrontEnd = resistencia / corrente

            // Dispor ao front-end:
            Toast.makeText(this, "O resultado em Ohms será de: $ResultadoFrontEnd", Toast.LENGTH_LONG).show()
        }




    }
}