package br.com.cluwt.ceplocal.Activity

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.com.cluwt.ceplocal.Model.Endereco
import br.com.cluwt.ceplocal.R

class ExibeEnderecoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_exibe_endereco2)
        val endereco = intent.getParcelableExtra<Endereco>("endereco")

        val textViewResultado = findViewById<TextView>(R.id.textViewResultado)
        textViewResultado.text = endereco?.toString()
    }
}