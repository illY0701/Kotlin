package br.com.cluwt.ceplocal.Model

import android.os.Parcel
import android.os.Parcelable

data class Endereco(
    val logradouro: String?,
    val bairro: String?,
    val localidade: String?,
    val uf: String?
) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(logradouro)
        parcel.writeString(bairro)
        parcel.writeString(localidade)
        parcel.writeString(uf)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Endereco> {
        override fun createFromParcel(parcel: Parcel): Endereco {
            return Endereco(parcel)
        }

        override fun newArray(size: Int): Array<Endereco?> {
            return arrayOfNulls(size)
        }
    }
}
