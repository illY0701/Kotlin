package br.com.cluwt.ceplocal.Service

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import br.com.cluwt.ceplocal.Model.Endereco

interface ViaCepService {
    @GET("{cep}/json/")
    fun consultarCep(@Path("cep") cep: String): Call<Endereco>
}