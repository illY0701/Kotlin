package br.com.cluwt.ceplocal.Activity

import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity

import br.com.cluwt.ceplocal.R

import android.content.Intent

import android.util.Log
import android.widget.Button
import android.widget.EditText

import br.com.cluwt.ceplocal.Model.Endereco
import br.com.cluwt.ceplocal.Service.ViaCepService
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory

class ConsultaCepActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consulta_cep)

        val cepInput = findViewById<EditText>(R.id.editTextCep)
        val buttonConsultar = findViewById<Button>(R.id.buttonConsultar)

        buttonConsultar.setOnClickListener {
            val cep = cepInput.text.toString()

            val retrofit = Retrofit.Builder()
                .baseUrl("https://viacep.com.br/ws/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            val service = retrofit.create(ViaCepService::class.java)
            val call = service.consultarCep(cep)

            call.enqueue(object : Callback<Endereco> {
                override fun onResponse(call: Call<Endereco>, response: Response<Endereco>) {
                    val endereco = response.body()
                    if (endereco != null) {
                        Log.d("Endereco", endereco.toString())
                        val intent = Intent(this@ConsultaCepActivity, ConsultaCepActivity::class.java)
                        intent.putExtra("endereco", endereco)
                        startActivity(intent)
                    }
                }

                override fun onFailure(call: Call<Endereco>, t: Throwable) {
                    Log.e("Erro", t.message.toString())
                }
            })
        }
    }
}
