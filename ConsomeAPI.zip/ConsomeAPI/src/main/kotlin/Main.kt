package br.edu.fatecpg

import com.google.gson.Gson

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val consumo = Consumo()
    print("Digite o CEP: ")
    val cep = readLine()?.replace(Regex("\\D"), "") ?: ""

    if (cep.length != 8) {
        println("CEP inválido. O CEP deve ter 8 dígitos.")
        return
    }

    val Endereco = consumo.buscaEndereco(cep)
    if (Endereco != null) {
        println(Endereco)
    } else {
        println("Não foi possível encontrar o endereço.")
    }
}