package br.edu.fatecpg

import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse.BodyHandlers
import org.json.JSONObject // Para processamento do JSON (você precisa adicionar a dependência org.json no seu projeto)

class Consumo {
    private val client: HttpClient = HttpClient.newHttpClient()

    fun buscaEndereco(cep: String): Endereco? {
        val request = HttpRequest.newBuilder()
            .uri(URI.create("https://viacep.com.br/ws/$cep/json/"))
            .build()

        val response = client.send(request, BodyHandlers.ofString())

        return if (response.statusCode() == 200) {
            val jsonResponse = response.body()
            parseEnderecoFromJson(jsonResponse)
        } else {
            println("Erro: Código de status ${response.statusCode()}")
            null
        }
    }

    private fun parseEnderecoFromJson(json: String): Endereco {
        val jsonObject = JSONObject(json)
        return Endereco(
            cep = jsonObject.optString("cep", "Não informado"),
            logradouro = jsonObject.optString("logradouro", "Não informado"),
            bairro = jsonObject.optString("bairro", "Não informado"),
            localidade = jsonObject.optString("localidade", "Não informado"),
            uf = jsonObject.optString("uf", "Não informado")
        )
    }
}